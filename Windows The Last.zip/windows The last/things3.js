document.getElementById("playButton").addEventListener("click", function() {
  var animation = document.getElementById("animation");
  var bgMusic = document.getElementById("bgMusic");

  // 播放GIF动画
  animation.style.display = "block";

  // 播放音乐
  bgMusic.play();

  // 在10秒后跳转到另一个界面
  setTimeout(function() {
    window.location.href = "user.php";
  }, 3000);
});