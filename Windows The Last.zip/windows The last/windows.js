function login() {
  let username = document.getElementById('天目').value;
  let password = document.getElementById('666').value;

  // 获取本地存储中保存的密码
  let storedPassword = localStorage.getItem(username);

  if (password === storedPassword) {
    alert('登录成功！');
    window.location.href = 'user.pho';
  } else {
    alert('用户名或密码错误，请重新输入');
  }

  document.getElementById('天目').value = '';
  document.getElementById('666').value = '';
}

document.addEventListener("DOMContentLoaded", function() {
  document.getElementById('login-form').addEventListener("submit", function(event) {
    event.preventDefault();
    login();
  });
});