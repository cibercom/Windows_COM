<!DOCTYPE html>
<html>
<head>
  <title>Windows登录界面</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
    }

    .container {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .login-box {
      background-color: #fff;
      width: 300px;
      border: 1px solid #ccc;
      padding: 20px;
    }

    .logo {
      text-align: center;
    }

    .logo img {
      width: 100px;
      height: 100px;
    }

    .input-group {
      margin-bottom: 10px;
    }

    .input-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }

    .input-group input {
      width: 100%;
      padding: 5px;
      font-size: 16px;
    }

    .login-button {
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: #fff;
      font-size: 16px;
      border: none;
      cursor: pointer;
    }

    .loader {
      margin-top: 20px;
      text-align: center;
    }

    .loader img {
      width: 40px;
      height: 40px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="login-box">
      <div class="logo">
        <img src="user.png" alt="Windows">
      </div>
      <div class="input-group">
        <label for="username">user</label>
        <input type="text" id="username" placeholder="请输入用户名">
      </div>
      <div class="input-group">
        <label for="password">pass</label>
        <input type="password" id="password" placeholder="请输入密码">
      </div>
      <button class="login-button" onclick="login()">登录</button>
      <div id="loader" class="loader" style="display: none;">
        <img src="windowsbegin1.gif" alt="Loading...">
      </div>
    </div>
  </div>

  <script>
    function login() {
      var username = document.getElementById("username").value;
      var password = document.getElementById("password").value;
      var loader = document.getElementById("loader");

      // 模拟登录验证
      if (username === "123456" && password === "123456") {
        loader.style.display = "block";
        setTimeout(function() {
          window.location.href = "WindowS.php"; // 跳转到仪表盘页面
        }, 3000); // 3秒后跳转
      }
    }
  </script>
</body>
</html>
<html>
<head>
    <title>Background Picture Example</title>
    <style>
        body {
            background-image: url("kj.png");
            background-size: cover;
  background-position: center;
</body>
</html>