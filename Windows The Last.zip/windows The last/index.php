注：计算完之后就跳出开机界面。例:1+1 = 等五秒
<!DOCTYPE html>
<html>

<head>
    <title>计算器</title>
    <style>
        .calculator {
            width: 100vw;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }

        .calculator-row {
            display: flex;
            justify-content: space-between;
            width: 300px;
        }

        .calculator-row button {
            flex: 1;
            height: 60px;
            font-size: 20px;
            margin: 5px;
        }

        .calculator-row button:last-child {
            margin-right: 0;
        }

        input {
            width: 300px;
            height: 60px;
            font-size: 24px;
            text-align: right;
            margin-bottom: 10px;
            padding: 5px;
            box-sizing: border-box;
        }
    </style>
</head>

<body>
    <div class="calculator">
        <input type="text" id="result" readonly>
        <div class="calculator-row">
            <button onclick="appendToScreen(7)">7</button>
            <button onclick="appendToScreen(8)">8</button>
            <button onclick="appendToScreen(9)">9</button>
            <button onclick="appendToScreen('/')">/</button>
        </div>
        <div class="calculator-row">
            <button onclick="appendToScreen(4)">4</button>
            <button onclick="appendToScreen(5)">5</button>
            <button onclick="appendToScreen(6)">6</button>
            <button onclick="appendToScreen('*')">*</button>
        </div>
        <div class="calculator-row">
            <button onclick="appendToScreen(1)">1</button>
            <button onclick="appendToScreen(2)">2</button>
            <button onclick="appendToScreen(3)">3</button>
            <button onclick="appendToScreen('-')">-</button>
        </div>
        <div class="calculator-row">
            <button onclick="appendToScreen(0)">0</button>
            <button onclick="appendToScreen('.')">.</button>
            <button onclick="calculate()">=</button>
            <button onclick="appendToScreen('+')">+</button>
        </div>
    </div>

    <script>
        function appendToScreen(value) {
            document.getElementById('result').value += value;
        }

        function calculate() {
            var result = eval(document.getElementById('result').value);
            document.getElementById('result').value = result;

            setTimeout(function() {
                window.location.href = "windowsbegin.html";
            }, 10000); // 5秒后跳转

            var audio = new Audio('into.mp3');
            audio.play();
        }
    </script>
</body>

</html>