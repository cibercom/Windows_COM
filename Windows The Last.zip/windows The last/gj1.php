<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>关机</title>
    <style>
        body {
            background-color: #0078D7;
            font-family: Arial, sans-serif;
        }
        
        .container {
            width: 400px;
            margin: 0 auto;
            padding: 100px;
            text-align: center;
            color: #FFF;
        }
        
        .loader {
            border: 16px solid #F3F3F3;
            border-top: 16px solid #3498DB;
            border-radius: 50%;
            width: 120px;
            height: 120px;
            animation: spin 2s linear infinite;
            margin: 0 auto;
            margin-bottom: 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        h1, p {
            margin: 10px 0;
        }
        
    </style>
    <script>
        setTimeout(function() {
            window.location.href = "gj2.php";
        }, 5000);
    </script>
</head>
<body>
    <div class="container">
        <div class="loader"></div>
        <h1>关机</h1>
        <p>正在关机中...</p>
    </div>
</body>
</html>