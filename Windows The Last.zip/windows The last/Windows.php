<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>加载中...</title>
<style>
body
{
    background-color: #0078d7;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}
#loader {
width: 100px;
height: 100px;
border: 10px solid #fff;
border-radius: 50%;
border-top-color: transparent;
animation: spin 1s infinite linear;
}
@keyframes spin
{
    0%
    {
        transform: rotate(0deg);
    }
    100%
    {
        transform: rotate(360deg);
    }
}
#message {
color: #fff;
font-size: 24px;
margin-top: 20px;
text-align: center;
}
</style>
<script>
setTimeout(function ()
{
    window.location.href = "windowshome.php";
}
, 5000);
</script>
</head>
<body>
<div id="loader"></div>
<div id="message">正在开机中</div>