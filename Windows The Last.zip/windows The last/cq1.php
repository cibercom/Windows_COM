<!DOCTYPE html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="button.css">
  <title>关机</title>
</head>
<body>
  <div class="container">
    <button id="playButton">关机</button>
  </div>

  <div id="animation"></div>

  <audio id="bgMusic" src="windows2.mp3"></audio>

  <script src="things2.js"></script>
</body>
<style>
body {
  background-repeat: no-repeat;
  background-size: cover;
  background-color: #0078d7; /* Windows蓝色背景的颜色代码 */
}
</style>
</head>
<body>
</body>
</html>