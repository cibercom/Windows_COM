<!DOCTYPE html>
<html>
<head>
<style>
.highlight
{
    font-size: 24px;
    font-weight: bold;
    color: red;
    text-align: center;
}
</style>
</head>
<body>
<div class="highlight">您已关机，请重启</div>
<title>您己关机</title>
<html>
<head>
<style>
.button
{
    padding: 10px 20px;
    background-color: #2ecc71;
    color: #ffffff;
    border: none;
    cursor: pointer;
}
</style>
</head>
<body>
<button class="button" onclick="changePage()">点击我重启</button>
<script>
function changePage()
{
    window.location.href = "cq2.php";
}
</script>
</body>
</html>