<head>
<title>天目机器人</title>
<style>
body
{
    font-family: Arial, sans-serif;
}
.message-container
{
    display: flex;
    flex-direction: column;
    height: 400px;
    max-width: 500px;
    margin: 0 auto;
    margin-top: 50px;
    border: 1px solid #ccc;
    border-radius: 10px;
    overflow-y: auto;
}
.message-container .message
{
    padding: 10px;
    margin: 10px;
    border-radius: 10px;
    font-size: 14px;
    max-width: 80%;
}
.message-container .user-message
{
    background-color: #DCF8C6;
    align-self: flex-start;
}
.message-container .bot-message
{
    background-color: #fff;
    align-self: flex-end;
}
.input-container
{
    display: flex;
    justify-content: center;
    margin-top: 20px;
}
.input-container input[type=text]
{
    padding: 10px;
    border-radius: 10px;
    border: 1px solid #ccc;
    width: 300px;
    font-size: 14px;
}
.input-container button
{
    padding: 10px 20px;
    border-radius: 10px;
    border: none;
    background-color: #4CAF50;
    color: white;
    font-size: 14px;
    cursor: pointer;
}
</style>
<style>
body
{
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    background-image: linear-gradient(to bottom, #FFFFFF 0%, transparent), url("https://api.vvhan.com/api/acgimg");
    background-position: top center;
    background-repeat: no-repeat;
    background-size: auto;
    transition: background-size 2s;
    height: 100vh;
    width: 100vw;
}
body:hover
{
    background-size: cover;
}
</style>
</head>
<body>
</body>
</html>
</head>
<body>
<div class="message-container" id="messageContainer"></div>
<div class="input-container">
<input type="text" id="userInput" placeholder="请输入你要发出的消息">
<button onclick="sendMessage()">发送</button>
</div>
<script>
const messageContainer = document.getElementById("messageContainer");
const userInput = document.getElementById("userInput");
const greetings =
{
    input: ["你好", "hi", "你好吗"],
    output: ["你好", "嗨，有什么可以帮助你的吗？", "我很好，谢谢你的关心！"]
}
;
function sendMessage()
{
    const userMessage = userInput.value;
    displayMessage(userMessage, "user");
    let botResponse = searchBotResponse(userMessage);
    displayMessage(botResponse, "bot");
    if (!document.getElementById("botSound"))
    {
        playSound();
    }
    userInput.value = "";
}
function displayMessage(message, sender)
{
    const messageElement = document.createElement("div");
    messageElement.classList.add("message");
    messageElement.classList.add(sender + "-message");
    messageElement.innerText = message;
    messageContainer.appendChild(messageElement);
    messageContainer.scrollTop = messageContainer.scrollHeight;
}
function searchBotResponse(userMessage)
{
    const botDictionary =
    {
        "你好": ["嗨，有什么可以帮助你的吗？", "我很好，谢谢你的关心！", "你好啊！"],
        "天气": ["今天天气晴朗，适合出门。", "明天会下雨，请记得带伞。"],
        "时间": ["现在是北京时间 12:00。", "现在是下午 3 点。"],
        "谢谢": ["不客气！", "你是怎么惹到我的？", "我很乐意帮助你。"],
        "早上好": ["早上好！今天有什么计划吗？", "早上好！祝你有一个美好的一天。"],
        "晚上好": ["晚上好！你今天过得怎么样？", "晚上好！有什么我可以帮助你的吗？"],
        "吃饭": ["你想吃什么？", "你喜欢吃什么食物呢？", "吃饭是件很享受的事情。"],
        "睡觉": ["晚安，祝你有个好梦！", "早点睡觉对身体好。"],
        "学习": ["坚持学习，不断进步！", "有什么科目你需要帮助吗？", "学习是人生不断成长的重要一环。"],
        "工作": ["工作辛苦，不要忘记休息哦！", "好好工作，加油！", "工作开心，事业有成！"],
        "喜欢": ["你喜欢做什么？", "喜欢的事情总是让人充满动力。"],
        "放松": ["放松一下，你做得很好！", "找些舒缓的音乐，放松一下身心。"],
        "健身": ["健身可以使你更健康，更有活力！", "运动是保持身体健康的好方法。"],
        "旅行": ["你喜欢去哪里旅行？", "旅行可以让你领略新鲜的风景和文化。"],
        "音乐": ["音乐是灵魂的抚慰，你喜欢什么类型的音乐？", "音乐有助于舒缓压力，放松心情。"],
        "读书": ["读书可以开阔你的视野，增长你的知识。", "你喜欢读什么类型的书籍？"],
        "电影": ["喜剧、动作、爱情片...你喜欢看哪种类型的电影？", "有没有什么好电影推荐？"],
        "美食": ["有什么美食是你的最爱？", "你喜欢尝试各种不同的美食吗？"],
        "购物": ["购物有时可以让人心情愉悦！", "是否有什么特定的东西你想买？"],
        "家庭": ["家庭是最温暖的港湾，你怎么看待你的家庭呢？", "家庭是人生中最重要的财富之一。"],
        "朋友": ["朋友是我们生活中的支持者和伙伴。", "你如何与朋友保持联系呢？"],
        "爱情": ["爱情是人生中最美好的事情之一。", "你对爱情有什么看法？"],
        "梦想": ["每个人都应该有自己的梦想，你想告诉我你的梦想吗？", "追逐梦想是人生的一大乐趣。"]
    }
    ;
    for (const key in botDictionary)
    {
        if (botDictionary.hasOwnProperty(key) && userMessage.includes(key))
        {
            const randomIndex = Math.floor(Math.random() * botDictionary[key].length);
            return botDictionary[key][randomIndex];
        }
    }
    return "对不起，我不明白你在说什么。";
}
function playSound()
{
    const audio = new Audio("ai.wav");
    audio.id = "botSound";
    audio.play();
}
</script>