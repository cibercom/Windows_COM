<!DOCTYPE html>
<html>
<head>
<title>Windows</title>
<style>
body
{
    background-image: url("windows666.png");
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    font-family: Arial, sans-serif;
    text-align: center;
    margin: 0;
    padding: 0;
}
#desktop {
display: flex;
justify-content: center;
align-items: center;
flex-wrap: wrap;
height: 100vh;
}
.icon
{
    flex: 0 0 auto;
    width: 180px;
    margin: 20px;
    text-align: center;
}
.icon img
{
    width: 100px;
    height: 100px;
    border-radius: 0;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
}
.icon p
{
    margin: 0;
    font-size: 15px;
}
#shutdown {
position: absolute;
bottom: 30px;
left: 50%;
transform: translateX(-50%);
}
#shutdown button {
background-color: #e74c3c;
color: white;
font-size: 15px;
border: none;
border-radius: 5px;
padding: 10px 20px;
cursor: pointer;
box-shadow: 0 3px 5px rgba(0, 0, 0, 0.3);
}
</style>
</head>
<body>
<div id="desktop">
<div class="icon">
<a href="https://m.bilibili.com/">
<img src="blbl.png" alt="图像1">
<p>哔哩哔哩</p>
</a>
</div>
<div class="icon">
<a href="https://www.bing.com/">
<img src="bing.png" alt="图像2">
<p>bing</p>
</a>
</div>
<div class="icon">
<a href="http://sglr.nb.hk.cn/">
<img src="sglr.png" alt="图像5">
<p>sglr官方网站</p>
</a>
</div>
<div class="icon">
<a href="slip/index.html">
<img src="sl.png" alt="图像6">
<p>扫雷</p>
</a>
</div>
<div class="icon">
<a href="http://venter.top/">
<img src="hopweb.png" alt="图像3">
<p>hopweb官方网站</p>
</a>
</div>
<div class="icon">
<a href="ai.php">
<img src="ai.png" alt="图像4">
<p>天目AI机器人</p>
</a>
</div>
<html>
<head>
<style>
.button
{
    background-color: transparent;
    border: none;
    color: red;
    padding: 15px 20px;
    text-align: center;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
.modal
{
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.8);
}
.modal-content
{
    background-color: transparent;
    margin: 15% auto;
    padding: 20px;
    width: 40%;
    border: 2px solid black;
    color: white;
    text-align: center;
}
.button:hover
{
    background-color: white;
    color: black;
}
.box
{
    width: 200px;
    height: 200px;
    border: 2px solid black;
    margin: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
}
.red
{
    background-color: red;
}
.blue
{
    background-color: blue;
}
.restart
{
    background-color: blue;
    border: none;
    color: white;
    text-decoration: none;
    padding: 15px 20px;
    text-align: center;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
.restart:hover
{
    background-color: darkblue;
}
.restart-container
{
    text-align: center;
}
</style>
</head>
<body>
<script>
function confirmShutdown()
{
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
}
function cancelShutdown()
{
    var modal = document.getElementById("myModal");
    modal.style.display = "none";
}
function restart()
{
    window.location.href = "cq.php";
    window.close();
}
</script>
<button id="shutdownButton" class="button" onclick="confirmShutdown()">点击关机</button>
<!-- 弹窗 -->
<div id="myModal" class="modal">
<div class="modal-content">
<h3>是否关机？</h3>
<button id="cancelButton" class="button" onclick="cancelShutdown()">取消</button>
<a href="gj1.php" class="button red">确认关机</a>
</div>
</div>
<div id="box" class="box"></div>
<!-- 重启按钮 -->
<div class="restart-container">
<button id="restartButton" class="restart" onclick="restart()">重启</button>
</div>
</body>
</html>