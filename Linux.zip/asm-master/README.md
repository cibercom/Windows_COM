# asm
assembly language examples, mostly Linux  

syscalls/linux/ - linux system call examples   
curl.asm - simple example of using libcurl   
curltomem.asm - libcurl to download file to memfd and exec it    
dlopen.asm - simple example of dlopen and dlsym with library    
dlmopen.asm - example of dlmopen alternate library loading  
libssh.asm - simple example of using libssh passwd auth  
libsshexec.asm - libssh passwd auth and execute command  
libsshcpexec.asm - libssh passwd auth sftp copy file and exec it  
libsshid.asm - libssh verify server identity via known hosts  
libsshkeyi.asm - libssh keyboard interactive auth  
pam.asm - simple example of using libpam   
wsl.asm - detect microsoft windows subsystem for linux  
